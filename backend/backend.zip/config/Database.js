import { Sequelize } from "sequelize";

// Database configuration using Sequelize
const db = new Sequelize('nayanika_admin', 'nayanika_admin', '%g!zYVKXRWt4', {
    host: 'https://api.nayanikaindo.com',  // Host for the database
    dialect: 'mysql',                      // Database dialect
    logging: false                         // Disable logging if not needed
});

export default db;
